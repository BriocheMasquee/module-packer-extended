---
name: "Chapter 1: The Approach"
slug: chapter-1-the-approach
rank: 0
parent: chapters
---

# Chapter 1: The Approach

> Rain needles down as your boat scrapes against the rocks. Above, the lighthouse's dark windows
> watch like empty eye sockets.
{.paper}

The party lands at a narrow shingle beach below the cliffs. Read or paraphrase the box above once
they're ashore.

Beachcombing along the shingle turns up whatever the tide has left — roll on the
[Shipwreck Flotsam](/roll/shipwreck-flotsam) table if a character searches the beach.

## The Cliff Path

A switchback trail climbs from the beach to the lighthouse door. Nothing blocks the way up, but
a character who studies the waterline notices something {.text-blue}*(DC 13 Wisdom (Perception))*{.text-blue}:
pale, waterlogged handprints on the rocks, leading up toward the tower — not down toward the sea.

Continue to [Chapter 2: The Lighthouse](chapter-2-the-lighthouse).
