---
name: "GM Notes"
slug: gm-notes
rank: 2
parent: 
---

# GM Notes

Background the players never see directly, plus the compendium content used throughout this
adventure.

## The Keeper's Fate

Ten years ago, keeper Old Rasgrim refused to abandon his post during the storm that sank the
merchant ship *Tallow's Grace*. He drowned trying to keep the light burning — and rose as the
first tide wraith, unable to let go of his post. The green light in the lantern room is his
lingering will, not truly magical fire.

If the party learns his name (a DC 15 History check, or asking in Saltmere) and speaks it to him
directly, he can be offered peace instead of a fight.

## Compendium content used in this adventure

The following are authored as standalone Compendium files (see the Compendium panel): the
[Rusty Cutlass](/item/rusty-cutlass) item, the [Mistward](/spell/mistward) spell, and the
[Tide Wraith](/monster/tide-wraith) monster (used for both wraiths in the ambush).

An inline block works the same way, written directly in a page instead of a separate file:

```item
name: "Lantern Keeper's Whistle"
slug: lantern-keepers-whistle
attributes:
  measurement: "imperial"
  ruleset: "5.5e"
image: "items/"
showImage: true
type: "wondrousItem"
typeDetail: ""
rarity: "uncommon"
attunement: true
attunementDetail: ""
value: 0
weight: 0
ac: 0
str: 0
stealth: false
properties: []
mastery: ""
dmg1: ""
dmg2: ""
dmgType: ""
range: ""
container: false
capacity: 0
descr: "A bone whistle that once called Rasgrim's shift change. Blown within the lighthouse, it draws the attention of anything undead on the same level."
sources:
  - name: "The Sunken Lighthouse"
    page: 9
showSources: true
tags: ["wondrous", "quest"]
showTags: true
```
