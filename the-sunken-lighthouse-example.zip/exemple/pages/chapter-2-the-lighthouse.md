---
name: "Chapter 2: The Lighthouse"
slug: chapter-2-the-lighthouse
rank: 1
parent: chapters
---

# Chapter 2: The Lighthouse

The lighthouse door hangs open, swollen with damp. Inside, a spiral stair winds up past a
flooded storage level. See the [Lighthouse Interior](lighthouse-interior) map for the full layout.

## The Flooded Base

> **Title** {.text-center}
>
> Cold seawater, knee-deep
{.flowchart}

Seawater has crept into the base through cracks in the old stonework. As the party crosses it,
run the [Tide Wraiths' Ambush](tide-wraiths-ambush) encounter.

If the party lingers here — resting, searching, or backtracking — a lone scavenger closes in,
authored directly inline instead of as a standalone Compendium file:

```monster
name: "Barnacle Crawler"
slug: barnacle-crawler
attributes:
  measurement: "imperial"
  ruleset: "5.5e"
image: "monsters/barnacle-crawler.png"
showImage: true
token: "monsters/barnacle-crawler-token.png"
showToken: true
size: "M"
type: "beast"
typeDetail: ""
alignment: "UU"
ac: "14"
hp: "18"
speed:
  walk: 20
  burrow: 0
  climb: 20
  fly: 0
  hover: false
  swim: 20
  other: ""
abilities: { str: 14, dex: 12, con: 13, int: 2, wis: 10, cha: 3 }
savingThrows: {}
skills: { stealth: 3 }
damageVulnerabilities: []
damageResistances: []
damageImmunities: []
conditionImmunities: []
senses:
  blindsight: 0
  darkvision: 30
  tremorsense: 0
  truesight: 0
  other: ""
passivePerception: 10
languages: []
cr: "1/2"
initiativeBonus: 1
proficiencyBonus: 2
environments: ["coastal"]
traits:
  - name: "Shell Camouflage"
    text: "The crawler has advantage on Dexterity (Stealth) checks made to hide among rocks or barnacle-crusted surfaces."
actions:
  - name: "Claw"
    text: "Melee Weapon Attack: +4 to hit, reach 5 ft., one target. Hit: 6 (1d8 + 2) slashing damage, and the target is grappled (escape DC 12)."
bonusActions: []
reactions: []
legendaryActions: []
descr: "A dog-sized crustacean, its shell fused with driftwood and old rope, that scuttles along the flooded lower level. Not intelligent, but territorial — it treats anything moving through its level as prey."
sources:
  - name: "The Sunken Lighthouse"
    page: 5
showSources: true
tags: ["beast", "aquatic"]
showTags: true
```

## Random Sounds

Roll (or pick) once per ten minutes the party spends inside.

Sounds Table {.table-title}

| [1d6](/roll/1d6) | Result |
|:---:|:---|
| 1 | A groan of settling stone far above |
| 2 | Dripping water, closer than it should be |
| 3 | The lantern room's light flickers on, then off |
| 4 | A distant, wordless singing |
| 5-6 | Silence, worse than any sound |

## The Lantern Room

At the top of the stair, the lantern still burns with a pale green witchlight — no oil, no flame,
just cold radiance. This is where the adventure's climax happens; see [GM Notes](gm-notes) for the
keeper's fate and how to resolve the light.
