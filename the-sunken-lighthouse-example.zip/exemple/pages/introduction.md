---
name: "Introduction"
slug: introduction
rank: 0
parent: 
---

# The Sunken Lighthouse

> The wind carries salt and something colder. Below the cliffs, the old lighthouse leans
> against the dark like it's waiting for the tide to finally take it.
{.read}

![The lighthouse at dusk, seen from the cliff road](images/lighthouse-exterior.png){.caption}

## Background

The lighthouse at Saltmere Point went dark ten years ago, after the keeper vanished during a
storm. Locals kept their distance — until three nights ago, when a pale green light started
flashing from the lantern room again.

| Hook | How it reaches the party |
| --- | --- |
| A worried harbormaster | Offers 50 gp to find out what's causing the light |
| A missing fisherman | His skiff washed up empty near the lighthouse dock |
{.blue}

## Running this adventure

This is a one-shot for **four characters of 3rd level**, playable in a single 3-4 hour session.
It assumes the party arrives by boat at low tide. See [Chapter 1](chapter-1-the-approach) to begin.
